package com.em.dao;

public interface RoleMapper {

    public String findNameById(Integer roleId);
}
