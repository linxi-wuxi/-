package com.em.service;


public interface RoleService {

    public String findNameById(Integer roleId) throws Exception;
}
