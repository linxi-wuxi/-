package com.em.domain;


//Reservation的扩展类
public class ReservationCustom extends Reservation {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
