package com.em.domain;

//日期分页

public class DateVo {
    private String next;

    public String getNext() {
        return next;
    }

    public void setNext(String next) {
        this.next = next;
    }
}
