-- --------------------------------------------------------
-- 主机:                           47.101.198.61
-- 服务器版本:                        10.3.21-MariaDB - MariaDB Server
-- 服务器操作系统:                      Linux
-- HeidiSQL 版本:                  10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- 导出 ssm_conference_room_yuyue 的数据库结构
CREATE DATABASE IF NOT EXISTS `ssm_conference_room_yuyue` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `ssm_conference_room_yuyue`;

-- 导出  表 ssm_conference_room_yuyue.reservation 结构
DROP TABLE IF EXISTS `reservation`;
CREATE TABLE IF NOT EXISTS `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room_id` int(11) DEFAULT NULL,
  `user` varchar(32) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `reason` varchar(32) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `begintime` time DEFAULT NULL,
  `endtime` time DEFAULT NULL,
  `mark` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_reservation_room` (`room_id`),
  CONSTRAINT `fk_reservation_room` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- 正在导出表  ssm_conference_room_yuyue.reservation 的数据：~14 rows (大约)
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` (`id`, `room_id`, `user`, `username`, `reason`, `mobile`, `date`, `begintime`, `endtime`, `mark`) VALUES
	(30, 1, 'user', NULL, NULL, '13022502404', '2020-01-29', '09:00:00', '13:00:00', '审核通过'),
	(31, 3, 'user', NULL, NULL, '13022502404', '2020-01-29', '09:00:00', '09:00:00', '取消申请'),
	(32, 1, 'user', NULL, NULL, '13022502404', '2020-02-01', '09:00:00', '09:00:00', '取消申请'),
	(33, 1, 'user', NULL, NULL, '13022502404', '2020-02-04', '09:00:00', '10:00:00', '审核通过'),
	(34, 1, 'user', NULL, NULL, '13022502404', '2020-02-06', '09:00:00', '10:00:00', '审核通过'),
	(35, 1, 'user', NULL, NULL, '13022502404', '2020-02-07', '09:00:00', '10:00:00', '审核通过'),
	(36, 1, 'user', NULL, NULL, '13022502404', '2020-02-09', '10:00:00', '11:00:00', '审核通过'),
	(38, 4, 'aaa', NULL, NULL, '12456278991', '2020-02-08', '13:00:00', '14:00:00', '审核通过'),
	(39, 5, 'aaa', NULL, NULL, '12456278991', '2020-02-09', '14:00:00', '15:00:00', '审核通过'),
	(40, 1, 'aaa', NULL, NULL, '12456278991', '2020-02-07', '10:30:00', '11:30:00', '审核通过'),
	(44, 1, 'user', NULL, NULL, '', '2020-02-27', '10:00:00', '11:00:00', '取消申请'),
	(45, 1, 'user', NULL, NULL, '11354', '2020-03-09', '09:00:00', '09:00:00', '取消申请'),
	(46, 1, 'user', '王二麻子', NULL, '12', '2020-03-14', '09:00:00', '09:00:00', '审核通过'),
	(47, 1, 'user', '王二麻子', '1', '```qqqqqqqq', '2020-03-14', '09:00:00', '09:00:00', '待审核'),
	(48, 1, 'user', '王二麻子', '租来学习', '13022502404', '2020-03-20', '09:00:00', '11:30:00', '待审核');
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;

-- 导出  表 ssm_conference_room_yuyue.role 结构
DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  ssm_conference_room_yuyue.role 的数据：~2 rows (大约)
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`role_id`, `role_name`) VALUES
	(1, 'admin'),
	(2, 'ordinary');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;

-- 导出  表 ssm_conference_room_yuyue.room 结构
DROP TABLE IF EXISTS `room`;
CREATE TABLE IF NOT EXISTS `room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `message` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- 正在导出表  ssm_conference_room_yuyue.room 的数据：~8 rows (大约)
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` (`id`, `name`, `message`) VALUES
	(1, 'J305', '大型会议室，可使用多媒体，适合开会、讲座'),
	(2, '第一会议室327', '能够使用多媒体，适合组会，论文答辩'),
	(3, '第三会议室329', '能够使用多媒体，适合开组会，硕/博士毕业论文答辩'),
	(4, 'J123', '大型会议室，可容纳200人，适合举办讲座'),
	(5, 'J226', '小包间会议室，适合小组讨论'),
	(6, 'J211', '小会议室，适合二十人小型会议，含多媒体'),
	(7, '顶尖军事科技图片站', '展览'),
	(12, '1', '1');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;

-- 导出  表 ssm_conference_room_yuyue.user 结构
DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(32) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `role` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_role` (`role`),
  CONSTRAINT `fk_user_role` FOREIGN KEY (`role`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 正在导出表  ssm_conference_room_yuyue.user 的数据：~8 rows (大约)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`, `username`, `password`, `role`) VALUES
	('201801', '张三', '123', 2),
	('233', '李四', '233', 2),
	('aaa', '', '123456', 2),
	('abc', '', '123456', 2),
	('admin', '管理员', 'admin', 1),
	('matou', '王三麻子', '123456', 2),
	('ordinary', '', '123456', 2),
	('user', '王二麻子1', '123456', 2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
