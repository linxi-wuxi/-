"""
    (2). 创建XXXView类,负责处理界面逻辑.
        绘制2048界面
        根据wsad键调用XXXController类中上下左右方法.
"""
from bll import GameController


class GameView:
    def __init__(self):
        self.controller = GameController()

    def display_key(self):
        print("w 向上移动")
        print("s 向下移动")
        print("a 向左移动")
        print("d 向右移动")

    def move(self):
        item = input("请输入移动方向")
        if item == "a":
            self.controller.move_left()
        elif item == "d":
            self.controller.move_right()
        elif item == "w":
            self.controller.move_up()
        elif item == "s":
            self.controller.move_down()


    def main(self):
        while True:
            self.display_key()
            self.move()

