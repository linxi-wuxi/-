from url import GameView
if __name__ == '__main__':
    view = GameView()
    view.main()



