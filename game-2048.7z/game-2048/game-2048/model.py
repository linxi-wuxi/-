
class GameModel:

    def __init__(self):
        self.list_merge = []
        self.map = []



