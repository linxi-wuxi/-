"""
    将参照student_manager_system结构,创建2048游戏.
    (1). 将day15/home_work/game2048中的核心算法,定义到XXXController类中,
          作为实例成员(全局变量->实例变量,函数-> 实例方法).
"""
from model import *

class GameController:

    def zero_to_end(self):
        for i in range(len(list_merge) - 1, -1, -1):
            if list_merge[i] == 0:
                del list_merge[i]
                list_merge.append(0)

    def merge(self):
        self.zero_to_end()
        for i in range(len(list_merge) - 1):
            if list_merge[i] == list_merge[i + 1]:
                list_merge[i] += list_merge[i + 1]
                del list_merge[i + 1]
                list_merge.append(0)

    def move_left(self):
        global list_merge
        for line in map:
            list_merge = line
            self.merge()

    def move_right(self):
        global list_merge
        for line in map:
            list_merge = line[::-1]
            self.merge()
            line[::-1] = list_merge

    def square_matrix_transposition(self,list_matrix):
        for c in range(1, len(list_matrix)):  # 1 2 3
            for r in range(c, len(list_matrix)):
               list_matrix[r][c - 1], list_matrix[c - 1][r] = list_matrix[c - 1][r], list_matrix[r][c - 1]

    def move_up(self):
        self.square_matrix_transposition(map)
        self.move_left()
        self.square_matrix_transposition(map)

    def move_down(self):
        self.square_matrix_transposition(map)
        self.move_left()
        self.square_matrix_transposition(map)

