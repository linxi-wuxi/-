from url import StudentView
view = StudentView()
view.main()